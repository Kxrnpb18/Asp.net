﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Product_Assignment3.Data;
using System;
using System.Linq;

namespace Product_Assignment3.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new Product_Assignment3Context(
                serviceProvider.GetRequiredService<
                    DbContextOptions<Product_Assignment3Context>>()))
            {
                // Look for any products.
                if (context.Product.Any())
                {
                    return;   // DB has been seeded
                }
                context.Product.AddRange(
                    new Product
                    {
                        Title = "Hammern Miller Chair",
                        PurchaseDate = DateTime.Parse("2023-9-12"),
                        Colour = "Black",
                        Description = "A chair that is black and has a hammern miller logo on it",
                        Price = "$600",
                        Quantity = "1"
                    },
                    new Product
                    {
                        Title = "Autonomous Pro Standing Desk",
                        PurchaseDate = DateTime.Parse("2023-12-12"),
                        Colour = "White",
                        Description = "A standing desk that is white and has autonomous logo on it",
                        Price = "$1000",
                        Quantity = "2"
                    },
                    new Product
                    {
                        Title = "Dell alienware 38 gaming monitor",
                        PurchaseDate = DateTime.Parse("2023-12-12"),
                        Colour = "White",
                        Description = "A gaming monitor that is white and has dell logo on it",
                        Price = "$800",
                        Quantity = "3"
                    },
                    new Product
                    {
                        Title = "HP Omen 15 Gaming Laptop",
                        PurchaseDate = DateTime.Parse("2023-12-12"),
                        Colour = "Silver",
                        Description = "A gaming laptop that is silver and has HP logo on it",
                        Price = "$2000",
                        Quantity = "4"
                    }
                );
                context.SaveChanges();
            }
        }
    }
}
