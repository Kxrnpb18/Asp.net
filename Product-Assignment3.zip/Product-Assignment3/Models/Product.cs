﻿using System.ComponentModel.DataAnnotations;

namespace Product_Assignment3.Models
{
    public class Product
    {
        // product details
        public int Id { get; set; }
        public string? Title { get; set; }
        [DataType(DataType.Date)]
        public DateTime PurchaseDate { get; set; }
        public string? Colour { get; set; }
        public string? Description { get; set; }
        public string? Price { get; set; }
        public string? Quantity { get; set; }
    }
}
