﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Product_Assignment3.Models;

namespace Product_Assignment3.Data
{
    public class Product_Assignment3Context : DbContext
    {
        public Product_Assignment3Context (DbContextOptions<Product_Assignment3Context> options)
            : base(options)
        {
        }

        public DbSet<Product_Assignment3.Models.Product> Product { get; set; } = default!;
    }
}
